package com.sky.skypil.poc;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.sky.skypil.poc.exception.NonRetryableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.lambda.powertools.sqs.SqsBatch;
import software.amazon.lambda.powertools.sqs.SqsMessageHandler;

public class SQSBatchLambdaHandler implements RequestHandler<SQSEvent, String> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SQSBatchLambdaHandler.class);
    @Override
    @SqsBatch(value = SingleMessageHandler.class, nonRetryableExceptions = {NonRetryableException.class})
    public String handleRequest(SQSEvent sqsEvent, Context context) {
        LOGGER.info("received: {}", sqsEvent);
        return null;
    }

    public class SingleMessageHandler implements SqsMessageHandler<Object> {
        @Override
        public String process(SQSMessage message) {
            // This will be called for each individual message from a batch
            // It should raise an exception if the message was not processed successfully
            String returnVal = processMessage(message);
            return returnVal;
        }
    }

    private String processMessage(SQSMessage message) {
        LOGGER.debug("message: {}", message);
        String content = message.getBody();
        if (content.contains("fail") || content.contains("reject")) {
            LOGGER.debug("message processing failed: {}", content);
            throw new RuntimeException("message processing failed:" + content);
        } else if (content.contains("nonretryable") || content.contains("unretryable")) {
            LOGGER.debug("message processing unretryable: {}", content);
            throw new NonRetryableException("message processing unretryable:" + content);
        } else {
            LOGGER.debug("message processing successful: {}", content);
        }
        return null;
    }
}
